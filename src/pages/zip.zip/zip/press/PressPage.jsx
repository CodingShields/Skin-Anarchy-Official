


const PressPage = () => {


    return (
        <div>
            <h1>Press Page</h1>
        </div>
    );
}