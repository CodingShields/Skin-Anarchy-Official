

const CelebrityPodcasts = () => {



    return (
        <div>
            <h1>Celebrity Podcast</h1>
        </div>
    )
}

export default CelebrityPodcasts;