const TopsDoctorsPodcasts = () => {
	return (
		<div>
			<h1>Top Doctors Podcasts</h1>
		</div>
	);
};

export default TopsDoctorsPodcasts;
