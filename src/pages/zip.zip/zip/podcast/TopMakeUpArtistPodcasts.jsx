



const TopMakeUpArtistPodcasts = () => {




    return (
        <div>
            <h1>MakeUp Artist Podcast</h1>
        </div>
    )
}

export default TopMakeUpArtistPodcasts;