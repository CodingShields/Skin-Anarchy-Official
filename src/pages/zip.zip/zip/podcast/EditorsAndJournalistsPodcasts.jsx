const EditorsAndJournalistsPodcasts = () => {
	return (
		<div>
			<h1>Journalist Podcast</h1>
		</div>
	);
};

export default EditorsAndJournalistsPodcasts;
