





const TopPicksCurrentYear = () => {


    return (
			<div className='flex w-fit h-fit justify-center bg-zinc-700 py-6 px-12 rounded-lg  space-x-12 mx-auto my-8 shadow-xl shadow-gray-500'>
            <h1>
                Top Picks Current Year</h1>
			</div>
		);
}

export default TopPicksCurrentYear