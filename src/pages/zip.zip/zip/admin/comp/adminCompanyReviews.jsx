



const AdminCompanyReviews = () => {



    return (
        <div>
            <h1>Company Reviews</h1>
            <div>
                <h1>Review Date</h1>
                <input type='date' />
                <h1>Company</h1>
                <input type='text' />
                <h1>Review</h1>
                <textarea type='text' />
                <h1>Rating</h1>
                <input type='number' />
                <h1>Image</h1>
                <input type='file' />
                <button>Submit</button>
                </div>
        </div>
    )
}

export default AdminCompanyReviews