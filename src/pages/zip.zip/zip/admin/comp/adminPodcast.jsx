const AdminPodcast = () => {
  return (
      <div
      className="flex flex-col items-center justify-start w-full h-full px-6 "
      >
          <h1
          className="text-5xl font-bold text-black w-fit text-center "
          >AdminPodcast</h1>
    </div>
  );
};

export default AdminPodcast;
