const AdminDashboard = () => {
	return (
		<div className='flex flex-col justify-center items-start h-full w-full'>
			<p className='text-center text-4xl font-bold text-gray-700 w-full border-b-2 border-black py-4 '>Skinanarchy Dashboard</p>
			<div
			className="flex flex-col justify-center items-center h-full w-full"
			>

			</div>
		</div>
	);
};

export default AdminDashboard;
