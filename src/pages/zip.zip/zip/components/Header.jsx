import NavBar from "../navBar/NavBar";
import "../../styles/custom.css";

const Header = () => {


	return (
		<div
		className="relative"
		>
			<NavBar />
		</div>
	);
};

export default Header;
