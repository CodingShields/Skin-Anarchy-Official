const FragranceBlog = () => {
	return (
		<div className='w-full h-[500px]'>
			<div className='w-3/4 h-full m-auto flex flex-col justify-center items-center text-white'>
				{" "}
				<h1>Fragrance Blog</h1>
			</div>
		</div>
	);
};

export default FragranceBlog;
