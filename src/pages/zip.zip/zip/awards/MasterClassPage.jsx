



const MasterClassPage = () => {




    return (

        <div
        className="flex flex-col justify-center items-center text-center h-screen w-full pt-10"
        >
            <h1>MasterClassPage</h1>
            <h1>Upcoming Master Class</h1>
            <h1>Master Class Title</h1>
            <h1>Master Class Date</h1>
            <h1>Master Class Time</h1>
            <h1>Master Class Description</h1>
            <h1>Master Class Image</h1>
            <button>Click Here To Reserve Your Spot</button>
        </div>
    )
}

export default MasterClassPage
