const FeaturedPress = () => {
	return (
        <div
        className="h-full w-full flex items-center justify-center bg-gray-200"
        >
			<h1>Featured Press Page</h1>
		</div>
	);
};

export default FeaturedPress;
